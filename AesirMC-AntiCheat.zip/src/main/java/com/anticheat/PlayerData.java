package com.anticheat;

import org.bukkit.Location;

public class PlayerData {
    private final Location location;
    private final long timestamp;

    public PlayerData(Location loc, long ts) {
        this.location = loc.clone();
        this.timestamp = ts;
    }

    public Location getLocation() {
        return location;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
