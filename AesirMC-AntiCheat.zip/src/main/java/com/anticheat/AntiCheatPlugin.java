package com.anticheat;

import com.anticheat.listener.MovementListener;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiCheatPlugin extends JavaPlugin {

    private static AntiCheatPlugin instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new MovementListener(this), this);
        getLogger().info("AntiCheat başlatıldı.");
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiCheat kapatıldı.");
    }

    public static AntiCheatPlugin getInstance() {
        return instance;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("anticheat")) return false;

        if (args.length == 0) {
            s.sendMessage("§aAntiCheat v1.0 - /anticheat reload");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission("anticheat.reload")) {
                s.sendMessage("§cYetkin yok.");
                return true;
            }
            reloadConfig();
            s.sendMessage("§aAyarlar yenilendi.");
            return true;
        }

        return true;
    }
}
