package com.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class DetectionLogger {

    private final AntiCheatPlugin plugin;

    public DetectionLogger(AntiCheatPlugin plugin) {
        this.plugin = plugin;
    }

    public void log(Player player, String reason, double val, double limit) {
        String msg = "§c[AntiCheat] " + player.getName() + " -> " + reason +
                " (value=" + val + ", limit=" + limit + ")";

        plugin.getLogger().warning(msg);

        if (plugin.getConfig().getBoolean("alerts.notifyOps")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("anticheat.alerts")) {
                    p.sendMessage(msg);
                }
            }
        }
    }
}
