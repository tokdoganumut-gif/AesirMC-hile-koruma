package com.anticheat.listener;

import com.anticheat.AntiCheatPlugin;
import com.anticheat.DetectionLogger;
import com.anticheat.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class MovementListener implements Listener {

    private final AntiCheatPlugin plugin;
    private final DetectionLogger logger;
    private final Map<UUID, PlayerData> lastPos = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> violations = new ConcurrentHashMap<>();

    public MovementListener(AntiCheatPlugin pl) {
        this.plugin = pl;
        this.logger = new DetectionLogger(pl);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();

        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR)
            return;

        Location f = e.getFrom();
        Location t = e.getTo();

        if (t == null || f.getX() == t.getX() && f.getY() == t.getY() && f.getZ() == t.getZ())
            return;

        long now = System.currentTimeMillis();
        PlayerData prev = lastPos.get(p.getUniqueId());

        if (prev == null) {
            lastPos.put(p.getUniqueId(), new PlayerData(t, now));
            return;
        }

        double dx = t.getX() - prev.getLocation().getX();
        double dy = t.getY() - prev.getLocation().getY();
        double dz = t.getZ() - prev.getLocation().getZ();

        double distXZ = Math.sqrt(dx * dx + dz * dz);
        double dt = Math.max(1, now - prev.getTimestamp()) / 1000.0;

        double horizSpeed = distXZ / dt;
        double vertSpeed = Math.abs(dy) / dt;

        double limit = plugin.getConfig().getDouble("thresholds.maxSpeedBase");
        if (p.isSprinting()) limit += plugin.getConfig().getDouble("thresholds.sprintBonus");

        if (p.hasPotionEffect(PotionEffectType.SPEED)) {
            int amp = p.getPotionEffect(PotionEffectType.SPEED).getAmplifier();
            limit += amp * plugin.getConfig().getDouble("thresholds.potionSpeedBonusPerLevel");
        }

        if (!p.isOnGround()) limit += plugin.getConfig().getDouble("thresholds.airExtra");

        double maxV = plugin.getConfig().getDouble("thresholds.maxVerticalSpeed");

        if (horizSpeed > limit) {
            detect(p, "Hız hilesi", horizSpeed, limit, prev);
        }

        if (!p.isOnGround() && vertSpeed > maxV &&
                !p.hasPotionEffect(PotionEffectType.LEVITATION) &&
                !p.hasPotionEffect(PotionEffectType.JUMP)) {

            detect(p, "Fly / Vertical hile", vertSpeed, maxV, prev);
        }

        lastPos.put(p.getUniqueId(), new PlayerData(t, now));
    }

    private void detect(Player p, String reason, double value, double limit, PlayerData prev) {
        logger.log(p, reason, value, limit);

        violations.putIfAbsent(p.getUniqueId(), 0);
        violations.put(p.getUniqueId(), violations.get(p.getUniqueId()) + 1);

        if (plugin.getConfig().getBoolean("actions.cancelMovement")) {
            Bukkit.getScheduler().runTask(plugin,
                    () -> p.teleport(prev.getLocation()));
        }

        int max = plugin.getConfig().getInt("actions.kickAfterViolations");
        if (plugin.getConfig().getBoolean("actions.kickPlayer") && max > 0 &&
                violations.get(p.getUniqueId()) >= max) {
            p.kickPlayer("AntiCheat: Hile tespit edildi.");
            violations.put(p.getUniqueId(), 0);
        }
    }
}
